# wiki-image-bot

Posts random images from Wikipedia to Mastodon.
